package javaFXSimpleApp;

public class Controller {
}
